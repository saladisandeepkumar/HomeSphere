package com.geekflow.home_fi

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
